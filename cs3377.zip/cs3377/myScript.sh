#!/bin/sh
mkdir a1part1
cd a1part1
mkdir folder1
cd folder1
touch file1
ls -l > file1
chmod 0600  file1
cd ~/cs3377/a1part1
mkdir folder2
cd folder2
touch file2
ls -l > file2
chmod 0744 file2
cd ~/cs3377/a1part1
touch file3
ls -l > file3
ln -s link1 file2

